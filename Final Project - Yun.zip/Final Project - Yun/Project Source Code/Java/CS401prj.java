package project_final;



import java.util.Scanner;

public class CS401prj {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt for data size input
        int dataSize = promptForDataSize(scanner);

        // Create and initialize DataManagement object for generating random data
        DataManagement dataManagement = new DataManagement(dataSize);
        System.out.println("Randomly generated data:");
        dataManagement.displayData(); // Display randomly generated data (optional)

        // Create MenuController object and display the main menu
        MenuController menuController = new MenuController(scanner, dataManagement);
        menuController.displayMainMenu();

        scanner.close();
    }

    // Method for prompting input of data size - repeat until a valid integer input is received
    private static int promptForDataSize(Scanner scanner) {
        int dataSize = 0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print("Enter the number of data elements to generate: ");
            if (scanner.hasNextInt()) {
                dataSize = scanner.nextInt();
                if (dataSize > 0) {
                    validInput = true; // Exit loop if input is valid
                } else {
                    System.out.println("Please enter a positive integer greater than 0.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Discard invalid input and continue to next input
            }
        }

        return dataSize;
    }
}
