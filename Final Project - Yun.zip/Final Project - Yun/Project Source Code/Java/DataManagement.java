package project_final;
import java.util.Arrays;
import java.util.Random;

/**
 * This class manages an array of Integer data and provides operations for data management.
 */
public class DataManagement {
    private Integer[] originalData; // Variable to maintain the original data
    private Integer[] data;

    /**
     * Constructor to initialize DataManagement with a specified size and generate random sample data.
     * @param size The size of the data array to be initialized.
     */
    public DataManagement(int size) {
        this.originalData = generateSampleData(size); // Generate original data
        resetData(); // Set initial data
    }

    /**
     * Generates an array of random integers between 0 and 999.
     * @param size The size of the array to generate.
     * @return An array of random integers.
     */
    private Integer[] generateSampleData(int size) {
        Integer[] data = new Integer[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            data[i] = random.nextInt(1000); // Random integers between 0 and 999
        }
        return data;
    }

    /**
     * Resets the data array with the original data.
     */
    public void resetData() {
        this.data = Arrays.copyOf(originalData, originalData.length); // Restore original data
    }

    /**
     * Get the current data array.
     * @return The array of Integer data.
     */
    public Integer[] getData() {
        return data;
    }

    /**
     * Get the size of the current data array.
     * @return The size of the data array.
     */
    public int getDataSize() {
        return data != null ? data.length : 0;
    }

    /**
     * Display the data array.
     */
    public void displayData() {
        if (data == null || data.length == 0) {
            System.out.println("No data to display.");
            return;
        }
        System.out.println("Data:");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
            if ((i + 1) % 10 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }

    /**
     * Add a new integer to the data array.
     * @param newData The new integer to be added.
     */
    public void addData(int newData) {
        data = Arrays.copyOf(data, data.length + 1);
        data[data.length - 1] = newData;
    }

    /**
     * Delete a specific integer from the data array.
     * @param deleteData The integer to be deleted.
     */
    public void deleteData(int deleteData) {
        if (data != null && data.length > 0) {
            data = Arrays.stream(data)
                    .filter(value -> value != deleteData)
                    .toArray(Integer[]::new);
        }
    }

    /**
     * Check if a specific integer exists in the data array.
     * @param searchData The integer to search for.
     * @return true if the integer exists, otherwise false.
     */
    public boolean containsData(int searchData) {
        if (data != null) {
            for (int value : data) {
                if (value == searchData) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Update an integer in the data array with a new value.
     * @param oldData The value to be updated.
     * @param newData The new value to replace the old value.
     */
    public void updateData(int oldData, int newData) {
        if (data != null) {
            for (int i = 0; i < data.length; i++) {
                if (data[i] == oldData) {
                    data[i] = newData;
                    break;
                }
            }
        }
    }

    /**
     * Update the entire data array with a new array of Integer data.
     * @param newData The new array of Integer data to replace the current data array.
     */
    public void updateDataArray(Integer[] newData) {
        this.data = newData;
    }

    /**
     * Replace a specific integer in the data array with a new value.
     * @param oldData The integer to be replaced.
     * @param newData The new value to replace the old integer.
     */
    public void replaceData(int oldData, int newData) {
        if (data != null) {
            for (int i = 0; i < data.length; i++) {
                if (data[i] == oldData) {
                    data[i] = newData;
                    break;
                }
            }
        }
    }

    /**
     * Calculate and display statistical summary of the data array.
     */
    public void displayDataStatistics() {
        if (data == null || data.length == 0) {
            System.out.println("No data to calculate statistics.");
            return;
        }

        // Calculate statistics
        int sum = Arrays.stream(data).mapToInt(Integer::intValue).sum();
        double average = (double) sum / data.length;

        Arrays.sort(data);
        int min = data[0];
        int max = data[data.length - 1];

        double median;
        if (data.length % 2 == 0) {
            median = (double) (data[data.length / 2] + data[data.length / 2 - 1]) / 2;
        } else {
            median = data[data.length / 2];
        }

        // Calculate variance
        double variance = 0;
        for (int num : data) {
            variance += Math.pow(num - average, 2);
        }
        variance /= data.length;

        // Calculate standard deviation
        double standardDeviation = Math.sqrt(variance);

        // Display statistics
        System.out.println("\nData Statistics:");
        System.out.println("Number of elements: " + data.length);
        System.out.println("Sum of elements: " + sum);
        System.out.println("Average value: " + average);
        System.out.println("Minimum value: " + min);
        System.out.println("Maximum value: " + max);
        System.out.println("Median value: " + median);
        System.out.println("Variance: " + variance);
        System.out.println("Standard deviation: " + standardDeviation);
    }
}
