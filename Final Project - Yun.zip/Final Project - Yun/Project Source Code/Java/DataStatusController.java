package project_final;


/**
 * This class is responsible for displaying the current status of data entries managed by a DataManagement instance.
 */
public class DataStatusController {
    private DataManagement dataManagement;

    /**
     * Constructor to initialize DataStatusController with a DataManagement instance.
     * @param dataManagement The DataManagement instance that manages the data entries.
     */
    public DataStatusController(DataManagement dataManagement) {
        this.dataManagement = dataManagement;
    }

    /**
     * Display the current number of data entries managed by the associated DataManagement instance.
     */
    public void displayDataQuantity() {
        int dataSize = dataManagement.getDataSize();
        System.out.println("Current number of data entries: " + dataSize);
    }
}
