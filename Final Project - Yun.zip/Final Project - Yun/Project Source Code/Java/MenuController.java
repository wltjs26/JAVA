package project_final;


import java.util.Scanner;

public class MenuController {
    private Scanner scanner;
    private DataManagement dataManagement;
    private SearchingAlgorithm searchingAlgorithm;
    private SortingAlgorithm sortingAlgorithm;

    public MenuController(Scanner scanner, DataManagement dataManagement) {
        this.scanner = scanner;
        this.dataManagement = dataManagement;
        this.searchingAlgorithm = new SearchingAlgorithm();
        this.sortingAlgorithm = new SortingAlgorithm();
    }

    public void displayMainMenu() {
        int choice;

        do {
            System.out.println("\nWarning: Once you have done searching or sorting, you will need to press menu 6 to reset data.");
            System.out.println("If you do not reset, the program will not work properly.");
            System.out.println("\nMenu:");
            System.out.println("1. Sort data");
            System.out.println("2. Search data");
            System.out.println("3. Display data");
            System.out.println("4. Other functions");
            System.out.println("5. Search Comparison");
            System.out.println("6. Reset Data");
            System.out.println("7. Data Analysis Report");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number between 1 and 8.");
                System.out.print("Enter your choice: ");
                scanner.next(); // Consume invalid input
            }

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    sortDataMenu();
                    break;
                case 2:
                    searchMenu();
                    break;
                case 3:
                    dataManagement.displayData();
                    break;
                case 4:
                    handleOtherFunctions();
                    break;
                case 5:
                    performSearchComparison();
                    break;
                case 6:
                    dataManagement.resetData();
                    System.out.println("Data reset to random values.");
                    break;
                case 7:
                    dataManagement.displayDataStatistics(); // 호출하여 데이터 분석 보고서 표시
                    break;
                case 8:
                    System.out.println("Exiting program... Bye. ");
                    break; // Exit the loop and end the program
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 8.");
            }

        } while (choice != 8); // Continue loop until the user chooses to exit

        // Close scanner after the loop ends
        scanner.close();
    }

    private void sortDataMenu() {
        String sortType;

        // Loop until a valid sort type is entered
        while (true) {
            scanner.nextLine(); // Clear input buffer
            System.out.print("Enter sort type (e.g., quick, merge, heap, selection, insertion, bubble): ");
            sortType = scanner.nextLine().trim().toLowerCase();

            Integer[] existingData = dataManagement.getData();

            // Process based on the entered sort type
            switch (sortType) {
                case "quick":
                    existingData = sortingAlgorithm.quickSort(existingData);
                    sortAndDisplay("Quick Sort", existingData);
                    return; // Exit the method after successful sort
                case "merge":
                    existingData = sortingAlgorithm.mergeSort(existingData);
                    sortAndDisplay("Merge Sort", existingData);
                    return; // Exit the method after successful sort
                case "heap":
                    existingData = sortingAlgorithm.heapSort(existingData);
                    sortAndDisplay("Heap Sort", existingData);
                    return; // Exit the method after successful sort
                case "selection":
                    existingData = sortingAlgorithm.selectionSort(existingData);
                    sortAndDisplay("Selection Sort", existingData);
                    return; // Exit the method after successful sort
                case "insertion":
                    existingData = sortingAlgorithm.insertionSort(existingData);
                    sortAndDisplay("Insertion Sort", existingData);
                    return; // Exit the method after successful sort
                case "bubble":
                    existingData = sortingAlgorithm.bubbleSort(existingData);
                    sortAndDisplay("Bubble Sort", existingData);
                    return; // Exit the method after successful sort
                default:
                    System.out.println("Invalid sort type. Please try again. Press Enter for a repeat run.");
                    // Continue the loop to prompt for sort type again
            }
        }
    }

    private void sortAndDisplay(String sortName, Integer[] sortedData) {
        System.out.println("Data sorted successfully with " + sortName + ":");
        dataManagement.updateDataArray(sortedData);
        dataManagement.displayData();
        System.out.println(sortName + " Sort Comparisons: " + sortingAlgorithm.getComparisonCount());
    }

    private void handleOtherFunctions() {
        OtherFunctionsController otherFunctionsController = new OtherFunctionsController(scanner, dataManagement);
        otherFunctionsController.handleOtherFunctions();
    }

    private void searchMenu() {
        System.out.print("Enter target value for search: ");
        int target;

        while (true) {
            if (scanner.hasNextInt()) {
                target = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                System.out.print("Enter target value for search: ");
                scanner.next(); // Consume invalid input
            }
        }

        scanner.nextLine(); // Consume newline character

        System.out.println("Choose search algorithm:");
        System.out.println("1. Binary Search");
        System.out.println("2. Linear Search");
        System.out.print("Enter your choice: ");

        int algorithmChoice;

        while (true) {
            if (scanner.hasNextInt()) {
                algorithmChoice = scanner.nextInt();
                if (algorithmChoice == 1 || algorithmChoice == 2) {
                    break; // Valid input, break loop
                } else {
                    System.out.println("Invalid input. Please enter 1 or 2.");
                    System.out.print("Enter your choice: ");
                }
            } else {
                System.out.println("Invalid input. Please enter 1 or 2.");
                System.out.print("Enter your choice: ");
                scanner.next(); // Consume invalid input
            }
        }

        scanner.nextLine(); // Consume newline character

        SearchingController searchingController = new SearchingController(scanner, dataManagement);

        switch (algorithmChoice) {
            case 1:
                searchingController.performBinarySearch(target);
                break;
            case 2:
                searchingController.performLinearSearch(target);
                break;
            default:
                System.out.println("Invalid choice. Performing linear search by default...");
                searchingController.performLinearSearch(target);
                break;
        }
    }

    private void performSearchComparison() {
        System.out.println("\nPerforming Search Comparison...");

        Integer[] existingData = dataManagement.getData();

        if (existingData == null || existingData.length == 0) {
            System.out.println("No data available for comparison. Please generate or input data.");
            return;
        }

        System.out.print("Enter the target value for search: ");
        int target;

        while (true) {
            if (scanner.hasNextInt()) {
                target = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                System.out.print("Enter the target value for search: ");
                scanner.next(); // Consume invalid input
            }
        }

        scanner.nextLine(); // Consume newline character

        SearchingAlgorithmComparison comparison = new SearchingAlgorithmComparison(scanner);
        comparison.performComparison(existingData, target);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements to generate and sort: ");
        int dataSize;

        while (true) {
            if (scanner.hasNextInt()) {
                dataSize = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                System.out.print("Enter the number of elements to generate and sort: ");
                scanner.next(); // Consume invalid input
            }
        }

        DataManagement dataManagement = new DataManagement(dataSize);
        MenuController menuController = new MenuController(scanner, dataManagement);
        menuController.displayMainMenu();

        // Do not close scanner here to allow continuous input handling
        // scanner.close();
    }
}
