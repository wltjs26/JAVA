package project_final;

import java.util.Scanner;

public class OtherFunctionsController {
    private Scanner scanner;
    private DataManagement dataManagement;
    private int[] deletedDataStack;
    private int top;

    public OtherFunctionsController(Scanner scanner, DataManagement dataManagement) {
        this.scanner = scanner;
        this.dataManagement = dataManagement;
        this.deletedDataStack = new int[dataManagement.getDataSize()];
        this.top = -1;
    }

    public void handleOtherFunctions() {
        int choice;
        do {
            System.out.println("\nOther Functions Menu:");
            System.out.println("1. Display status of data quantity");
            System.out.println("2. Add data");
            System.out.println("3. Delete data");
            System.out.println("4. Restore data");
            System.out.println("5. Update data");
            System.out.println("6. Return to main menu");
            System.out.print("Enter your choice: ");

            // Loop until a valid integer choice between 1 and 6 is entered
            while (true) {
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                    if (choice >= 1 && choice <= 6) {
                        break; // Valid input, break loop
                    } else {
                        System.out.println("Invalid choice. Please enter a number between 1 and 6.");
                        System.out.print("Enter your choice: ");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a valid integer.");
                    System.out.print("Enter your choice: ");
                    scanner.next(); // Consume the invalid input
                }
            }

            switch (choice) {
                case 1:
                    displayDataQuantity();
                    break;
                case 2:
                    addData();
                    break;
                case 3:
                    deleteData();
                    break;
                case 4:
                    restoreData();
                    break;
                case 5:
                    replaceData();
                    break;
                case 6:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 6.");
            }
        } while (choice != 6);
    }

    private void displayDataQuantity() {
        System.out.println("Total data elements: " + dataManagement.getDataSize());
    }

    private void addData() {
        int newData;
        while (true) {
            System.out.print("Enter data to add: ");
            if (scanner.hasNextInt()) {
                newData = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Consume invalid input
            }
        }
        dataManagement.addData(newData);
        System.out.println("Data added successfully.");
    }

    private void deleteData() {
        int deleteData;
        while (true) {
            System.out.print("Enter data to delete: ");
            if (scanner.hasNextInt()) {
                deleteData = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Consume invalid input
            }
        }

        if (dataManagement.containsData(deleteData)) {
            dataManagement.deleteData(deleteData);
            deletedDataStack[++top] = deleteData;
            System.out.println("Data deleted and stored in stack.");
        } else {
            System.out.println("Data not found. Deletion failed.");
        }
    }

    private void restoreData() {
        if (top == -1) {
            System.out.println("No data to restore. Stack is empty.");
        } else {
            int restoredData = deletedDataStack[top--];
            dataManagement.addData(restoredData);
            System.out.println("Data restored successfully.");
        }
    }

    private void replaceData() {
        int oldData;
        while (true) {
            System.out.print("Enter data to replace: ");
            if (scanner.hasNextInt()) {
                oldData = scanner.nextInt();
                break; // Valid input, break loop
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Consume invalid input
            }
        }

        if (dataManagement.containsData(oldData)) {
            int newData;
            while (true) {
                System.out.print("Enter new data value: ");
                if (scanner.hasNextInt()) {
                    newData = scanner.nextInt();
                    break; // Valid input, break loop
                } else {
                    System.out.println("Invalid input. Please enter a valid integer.");
                    scanner.next(); // Consume invalid input
                }
            }

            dataManagement.replaceData(oldData, newData);
            System.out.println("Data replaced successfully.");
        } else {
            System.out.println("Data not found. Replacement failed.");
        }
    }
}
