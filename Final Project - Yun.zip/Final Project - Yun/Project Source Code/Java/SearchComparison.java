package project_final;


import java.util.*;

/**
 * This class `SearchComparison` demonstrates the comparison of different search algorithms
 * (linear search, binary search, and hash function search) on randomly generated data.
 */
public class SearchComparison {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number of data elements to generate
        System.out.print("Enter the number of data elements to generate: ");
        int dataSize = scanner.nextInt();

        // Generate random data
        Integer[] data = generateRandomData(dataSize);

        // Choose a target value (randomly select from the generated data)
        Random random = new Random();
        int target = data[random.nextInt(dataSize)];

        // Measure time taken for linear search
        long startTime = System.nanoTime();
        int linearSearchResult = linearSearch(data, target);
        long linearSearchTime = System.nanoTime() - startTime;

        // Sort the data for binary search
        Arrays.sort(data);

        // Measure time taken for binary search
        startTime = System.nanoTime();
        int binarySearchResult = binarySearch(data, target);
        long binarySearchTime = System.nanoTime() - startTime;

        // Create a hash table using the data
        Map<Integer, Integer> hashTable = createHashTable(data);

        // Measure time taken for hash function search
        startTime = System.nanoTime();
        boolean hashSearchResult = hashFunctionSearch(hashTable, target);
        long hashSearchTime = System.nanoTime() - startTime;

        // Print results
        System.out.println("Linear Search:");
        if (linearSearchResult != -1) {
            System.out.println("Target found at index: " + linearSearchResult);
        } else {
            System.out.println("Target not found.");
        }
        System.out.println("Linear Search Time (nanoseconds): " + linearSearchTime);

        System.out.println("\nBinary Search:");
        if (binarySearchResult != -1) {
            System.out.println("Target found at index: " + binarySearchResult);
        } else {
            System.out.println("Target not found.");
        }
        System.out.println("Binary Search Time (nanoseconds): " + binarySearchTime);

        System.out.println("\nHash Function Search:");
        if (hashSearchResult) {
            System.out.println("Target found using hash function.");
        } else {
            System.out.println("Target not found using hash function.");
        }
        System.out.println("Hash Function Search Time (nanoseconds): " + hashSearchTime);

        scanner.close();
    }

    /**
     * Generates an array of random integers.
     *
     * @param size The number of random integers to generate.
     * @return An array of random integers.
     */
    private static Integer[] generateRandomData(int size) {
        Random random = new Random();
        Integer[] data = new Integer[size];
        for (int i = 0; i < size; i++) {
            data[i] = random.nextInt(1000); // Generate random integers between 0 and 999
        }
        return data;
    }

    /**
     * Performs linear search on the given array of data.
     *
     * @param data The array of data to search within.
     * @param target The target value to search for.
     * @return The index of the target value if found, otherwise -1.
     */
    private static int linearSearch(Integer[] data, int target) {
        for (int i = 0; i < data.length; i++) {
            if (data[i].equals(target)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Performs binary search on the given sorted array of data.
     *
     * @param data The sorted array of data to search within.
     * @param target The target value to search for.
     * @return The index of the target value if found, otherwise -1.
     */
    private static int binarySearch(Integer[] data, int target) {
        int low = 0;
        int high = data.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (data[mid].equals(target)) {
                return mid;
            } else if (data[mid].compareTo(target) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    /**
     * Creates a hash table (HashMap) from the given array of data.
     *
     * @param data The array of data to create the hash table from.
     * @return A HashMap representing the hash table.
     */
    private static Map<Integer, Integer> createHashTable(Integer[] data) {
        Map<Integer, Integer> hashTable = new HashMap<>();
        for (int num : data) {
            hashTable.put(num, num); // Use the number itself as the value for simplicity
        }
        return hashTable;
    }

    /**
     * Performs hash function search in the given hash table for the specified target value.
     *
     * @param hashTable The hash table to perform the search within.
     * @param target The target value to search for.
     * @return true if the target value is found in the hash table, otherwise false.
     */
    private static boolean hashFunctionSearch(Map<Integer, Integer> hashTable, int target) {
        return hashTable.containsKey(target);
    }
}
