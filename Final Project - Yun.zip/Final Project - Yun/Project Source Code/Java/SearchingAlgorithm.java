package project_final;


import java.util.HashMap;
import java.util.Map;

/**
 * The `SearchingAlgorithm` class implements various searching and sorting algorithms
 * including linear search, binary search, and quick sort. It also provides methods to
 * work with a hash table for efficient searching.
 */
public class SearchingAlgorithm {

    private Map<Integer, Integer> hashTable;
    private int comparisonCount; // Variable to store comparison count

    /**
     * Constructs a new `SearchingAlgorithm` with an empty hash table and initializes
     * the comparison count to zero.
     */
    public SearchingAlgorithm() {
        this.hashTable = new HashMap<>();
        this.comparisonCount = 0; // Initialize comparison count to zero
    }

    /**
     * Inserts a key-value pair into the hash table.
     *
     * @param key   The key to insert.
     * @param value The value associated with the key.
     */
    public void insertIntoHashTable(int key, int value) {
        hashTable.put(key, value);
    }

    /**
     * Searches for a key-value pair in the hash table.
     *
     * @param key   The key to search for.
     * @param value The value to match against the key's associated value.
     * @return true if the key is found with the specified value, otherwise false.
     */
    public boolean searchInHashTable(int key, int value) {
        return hashTable.containsKey(key) && hashTable.get(key) == value;
    }

    /**
     * Performs linear search on the given array of data to find the target value.
     *
     * @param data   The array of data to search within.
     * @param target The target value to search for.
     * @return The index of the target value if found, otherwise -1.
     */
    public int linearSearch(Integer[] data, int target) {
        comparisonCount = 0; // Reset comparison count
        for (int i = 0; i < data.length; i++) {
            comparisonCount++; // Increment comparison count
            if (data[i] == target) {
                return i; // Target found, return index
            }
        }
        return -1; // Target not found
    }

    /**
     * Performs binary search on the given sorted array of data to find the target value.
     *
     * @param sortedData The sorted array of data to search within.
     * @param target     The target value to search for.
     * @return The index of the target value if found, otherwise -1.
     */
    public int binarySearch(Integer[] sortedData, int target) {
        comparisonCount = 0; // Reset comparison count
        int low = 0;
        int high = sortedData.length - 1;

        while (low <= high) {
            comparisonCount++; // Increment comparison count
            int mid = low + (high - low) / 2;
            if (sortedData[mid] == target) {
                return mid; // Target found, return index
            } else if (sortedData[mid] < target) {
                low = mid + 1; // Continue search in the right half
            } else {
                high = mid - 1; // Continue search in the left half
            }
        }

        return -1; // Target not found
    }

    /**
     * Sorts the given array of integers using the quick sort algorithm.
     *
     * @param array The array of integers to be sorted.
     */
    public void quickSort(Integer[] array) {
        if (array == null || array.length == 0) {
            return;
        }
        comparisonCount = 0; // Reset comparison count
        quickSort(array, 0, array.length - 1);
    }

    /**
     * Recursively performs quick sort on the subarray of integers.
     *
     * @param array The array to be sorted.
     * @param low   The starting index of the subarray.
     * @param high  The ending index of the subarray.
     */
    private void quickSort(Integer[] array, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(array, low, high);
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }

    /**
     * Partitions the array into two parts based on the pivot element.
     *
     * @param array The array to be partitioned.
     * @param low   The starting index of the partition.
     * @param high  The ending index of the partition.
     * @return The index of the pivot element.
     */
    private int partition(Integer[] array, int low, int high) {
        int pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {
                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                comparisonCount++; // Increment comparison count
            }
        }

        int temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;
        comparisonCount++; // Increment comparison count

        return i + 1;
    }

    /**
     * Retrieves the total number of comparisons made during the last search or sort operation.
     *
     * @return The number of comparisons.
     */
    public int getComparisonCount() {
        return comparisonCount;
    }
}
