package project_final;

import java.util.Arrays;
import java.util.Scanner;

public class SearchingAlgorithmComparison {

    private SearchingAlgorithm searchingAlgorithm;
    private SortingAlgorithm sortingAlgorithm;
    private Scanner scanner;

    public SearchingAlgorithmComparison(Scanner scanner) {
        this.searchingAlgorithm = new SearchingAlgorithm();
        this.sortingAlgorithm = new SortingAlgorithm();
        this.scanner = scanner;
    }

    // Method to perform comparison of search algorithms
    public void performComparison(Integer[] data, int target) {
        // Perform linear search and measure time and comparisons
        long linearStartTime = System.nanoTime();
        int linearSearchResult = searchingAlgorithm.linearSearch(data, target);
        long linearTime = System.nanoTime() - linearStartTime;
        int linearComparisons = searchingAlgorithm.getComparisonCount();

        // Sort data for binary search
        Integer[] sortedData = Arrays.copyOf(data, data.length); // Create a copy to preserve the original data
        sortingAlgorithm.quickSort(sortedData);

        // Perform binary search and measure time and comparisons
        long binaryStartTime = System.nanoTime();
        int binarySearchResult = searchingAlgorithm.binarySearch(sortedData, target);
        long binaryTime = System.nanoTime() - binaryStartTime;
        int binaryComparisons = searchingAlgorithm.getComparisonCount();

        // Create a hash table for hash function search
        SearchingAlgorithm hashAlgorithm = new SearchingAlgorithm();
        for (Integer value : data) {
            hashAlgorithm.insertIntoHashTable(value, value);
        }

        // Perform hash function search and measure time
        long hashStartTime = System.nanoTime();
        boolean hashSearchResult = hashAlgorithm.searchInHashTable(target, target);
        long hashTime = System.nanoTime() - hashStartTime;

        // Print comparison results
        System.out.println("Target Value: " + target);
        System.out.println("Linear Search:");
        System.out.println("Result: " + (linearSearchResult != -1 ? "Found at index " + linearSearchResult : "Not found"));
        System.out.println("Time (nanoseconds): " + linearTime);
        System.out.println("Comparisons: " + linearComparisons);

        System.out.println("\nBinary Search:");
        System.out.println("Result: " + (binarySearchResult != -1 ? "Found at index " + binarySearchResult : "Not found"));
        System.out.println("Time (nanoseconds): " + binaryTime);
        System.out.println("Comparisons: " + binaryComparisons);

        System.out.println("\nHash Function Search:");
        System.out.println("Result: " + (hashSearchResult ? "Found" : "Not found"));
        System.out.println("Time (nanoseconds): " + hashTime);
    }

    // Method to compare search algorithms
    public void compareSearchAlgorithms(Integer[] data, int target) {
        System.out.println("Search Algorithm Performance Comparison:");

        // Perform linear search and measure time and comparisons
        compareAlgorithm("Linear Search", () -> {
            int result = searchingAlgorithm.linearSearch(data, target);
            int comparisons = searchingAlgorithm.getComparisonCount();
            return new SearchResult(result, comparisons);
        });

        // Sort data for binary search
        Integer[] sortedData = Arrays.copyOf(data, data.length);
        sortingAlgorithm.quickSort(sortedData);

        // Perform binary search and measure time and comparisons
        compareAlgorithm("Binary Search", () -> {
            int result = searchingAlgorithm.binarySearch(sortedData, target);
            int comparisons = searchingAlgorithm.getComparisonCount();
            return new SearchResult(result, comparisons);
        });

        // Create a hash table for hash function search
        SearchingAlgorithm hashAlgorithm = new SearchingAlgorithm();
        for (Integer value : data) {
            hashAlgorithm.insertIntoHashTable(value, value);
        }

        // Perform hash function search and measure time
        compareAlgorithm("Hash Function Search", () -> {
            boolean result = hashAlgorithm.searchInHashTable(target, target);
            return new BooleanResult(result);
        });
    }

    private void compareAlgorithm(String algorithmName, ResultSupplier supplier) {
        long startTime = System.nanoTime();
        Result result = supplier.get();
        long endTime = System.nanoTime();
        long executionTime = endTime - startTime;

        System.out.println(algorithmName + ":");
        System.out.println("Result: " + result);
        System.out.println("Time (nanoseconds): " + executionTime);
    }

    @FunctionalInterface
    private interface ResultSupplier {
        Result get();
    }

    private interface Result {
    }

    private static class SearchResult implements Result {
        private final int index;
        private final int comparisons;

        public SearchResult(int index, int comparisons) {
            this.index = index;
            this.comparisons = comparisons;
        }

        @Override
        public String toString() {
            return (index != -1 ? "Found at index " + index : "Not found") + ", Comparisons: " + comparisons;
        }
    }

    private static class BooleanResult implements Result {
        private final boolean result;

        public BooleanResult(boolean result) {
            this.result = result;
        }

        @Override
        public String toString() {
            return result ? "Found" : "Not found";
        }
    }
}
