package project_final;


import java.util.Scanner;

public class SearchingController {
    private Scanner scanner;
    private DataManagement dataManagement;
    private SortingAlgorithm sortingAlgorithm;

    public SearchingController(Scanner scanner, DataManagement dataManagement) {
        this.scanner = scanner;
        this.dataManagement = dataManagement;
        this.sortingAlgorithm = new SortingAlgorithm();
    }

    public void searchMenu() {
        System.out.print("Enter target value for search: ");
        int target = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Choose search algorithm:");
        System.out.println("1. Binary Search");
        System.out.println("2. Linear Search");
        System.out.print("Enter your choice: ");
        int algorithmChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline after reading choice

        switch (algorithmChoice) {
            case 1:
                performBinarySearch(target);
                break;
            case 2:
                performLinearSearch(target);
                break;
            default:
                System.out.println("Invalid choice. Performing linear search by default...");
                performLinearSearch(target);
                break;
        }
    }

    public void performBinarySearch(int target) {
        Integer[] currentData = dataManagement.getData();
        sortingAlgorithm.quickSort(currentData);
        int index = binarySearch(currentData, target);
        if (index != -1) {
            System.out.println("Binary Search: Target found at index " + index);
        } else {
            System.out.println("Binary Search: Target not found");
        }
    }

    public void performLinearSearch(int target) {
        Integer[] currentData = dataManagement.getData();
        int index = linearSearch(currentData, target);
        if (index != -1) {
            System.out.println("Linear Search: Target found at index " + index);
        } else {
            System.out.println("Linear Search: Target not found");
        }
    }

    private int binarySearch(Integer[] array, int target) {
        int left = 0;
        int right = array.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid;
            } else if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Target not found
    }

    private int linearSearch(Integer[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i;
            }
        }
        return -1; // Target not found
    }
}

