package project_final;

/**
 * This class implements various sorting algorithms such as Quick Sort, Merge Sort, Heap Sort,
 * Selection Sort, Insertion Sort, and Bubble Sort. Each sorting algorithm provides a method to
 * sort an array of Integers and also keeps track of the number of comparisons made during sorting.
 */
public class SortingAlgorithm {
    private int comparisonCount; // Variable to store comparison count

    /**
     * Constructor to initialize a SortingAlgorithm object.
     * Initializes the comparison count to zero.
     */
    public SortingAlgorithm() {
        this.comparisonCount = 0; // Initialize comparison count to zero
    }

    /**
     * Perform Quick Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] quickSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        quickSort(array, 0, array.length - 1);
        return array;
    }

    /**
     * Helper method for Quick Sort.
     * @param array The array of Integers to be sorted.
     * @param low The starting index of the array segment to be sorted.
     * @param high The ending index of the array segment to be sorted.
     */
    private void quickSort(Integer[] array, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(array, low, high);
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }

    /**
     * Partition method for Quick Sort.
     * @param array The array of Integers to be sorted.
     * @param low The starting index of the array segment to be partitioned.
     * @param high The ending index of the array segment to be partitioned.
     * @return The index of the pivot element after partitioning.
     */
    private int partition(Integer[] array, int low, int high) {
        int pivot = array[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (array[j] < pivot) {
                i++;
                swap(array, i, j);
            }
            comparisonCount++; // Increment comparison count for each comparison
        }
        swap(array, i + 1, high);
        return i + 1;
    }

    /**
     * Perform Merge Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] mergeSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        mergeSort(array, 0, array.length - 1);
        return array;
    }

    /**
     * Helper method for Merge Sort.
     * @param array The array of Integers to be sorted.
     * @param left The starting index of the array segment to be sorted.
     * @param right The ending index of the array segment to be sorted.
     */
    private void mergeSort(Integer[] array, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(array, left, mid);
            mergeSort(array, mid + 1, right);
            merge(array, left, mid, right);
        }
    }

    /**
     * Merge method for Merge Sort.
     * @param array The array of Integers to be sorted.
     * @param left The starting index of the left subarray.
     * @param mid The ending index of the left subarray and the starting index of the right subarray.
     * @param right The ending index of the right subarray.
     */
    private void merge(Integer[] array, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Integer[] L = new Integer[n1];
        Integer[] R = new Integer[n2];

        System.arraycopy(array, left, L, 0, n1);
        System.arraycopy(array, mid + 1, R, 0, n2);

        int i = 0, j = 0;
        int k = left;
        while (i < n1 && j < n2) {
            comparisonCount++;
            if (L[i] <= R[j]) {
                array[k++] = L[i++];
            } else {
                array[k++] = R[j++];
            }
        }

        while (i < n1) {
            array[k++] = L[i++];
        }
        while (j < n2) {
            array[k++] = R[j++];
        }
    }

    /**
     * Perform Heap Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] heapSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        int n = array.length;

        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(array, n, i);
        }

        for (int i = n - 1; i > 0; i--) {
            swap(array, 0, i);
            heapify(array, i, 0);
        }

        return array;
    }

    /**
     * Helper method to heapify a subtree rooted at index i.
     * @param array The array of Integers to be sorted.
     * @param n The size of the heap.
     * @param i The index of the root of the subtree to be heapified.
     */
    private void heapify(Integer[] array, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && array[left] > array[largest]) {
            comparisonCount++;
            largest = left;
        }

        if (right < n && array[right] > array[largest]) {
            comparisonCount++;
            largest = right;
        }

        if (largest != i) {
            swap(array, i, largest);
            heapify(array, n, largest);
        }
    }

    /**
     * Perform Selection Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] selectionSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        int n = array.length;

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                comparisonCount++;
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            swap(array, i, minIndex);
        }

        return array;
    }

    /**
     * Perform Insertion Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] insertionSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        int n = array.length;

        for (int i = 1; i < n; i++) {
            int key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
                comparisonCount++; // Increment comparison count for each comparison
            }
            array[j + 1] = key;
        }

        return array;
    }

    /**
     * Perform Bubble Sort on the input array.
     * @param array The array of Integers to be sorted.
     * @return The sorted array of Integers.
     */
    public Integer[] bubbleSort(Integer[] array) {
        comparisonCount = 0; // Reset comparison count
        int n = array.length;

        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                comparisonCount++;
                if (array[j] > array[j + 1]) {
                    swap(array, j, j + 1);
                    swapped = true;
                }
            }
            if (!swapped) {
                break; // If no swaps occurred, the array is already sorted
            }
        }

        return array;
    }

    /**
     * Helper method to swap elements in an array.
     * @param array The array containing the elements to be swapped.
     * @param i The index of the first element to be swapped.
     * @param j The index of the second element to be swapped.
     */
    private void swap(Integer[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    /**
     * Display the elements of the array.
     * @param array The array of Integers to be displayed.
     */
    public void displayArray(Integer[] array) {
        for (Integer value : array) {
            System.out.print(value + " ");
        }
        System.out.println(); // Print a new line after displaying the array
    }

    /**
     * Get the total comparison count during sorting.
     * @return The total number of comparisons made during sorting.
     */
    public int getComparisonCount() {
        return comparisonCount;
    }
}
