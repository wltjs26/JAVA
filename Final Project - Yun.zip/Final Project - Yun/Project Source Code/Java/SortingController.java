package project_final;


import java.util.*;

/**
 * The `SortingController` class manages sorting operations using various sorting algorithms provided by the `SortingAlgorithm` class.
 * It serves as an intermediary between user input (via `Scanner` object) and data management (`DataManagement` class).
 */
public class SortingController {
    private Scanner scanner;
    private DataManagement dataManagement;
    private SortingAlgorithm sortingAlgorithm;

    /**
     * Constructs a `SortingController` with the given `Scanner` object and `DataManagement` object.
     *
     * @param scanner       Scanner object for user input
     * @param dataManagement DataManagement object to manage data
     */
    public SortingController(Scanner scanner, DataManagement dataManagement) {
        this.scanner = scanner;
        this.dataManagement = dataManagement;
        this.sortingAlgorithm = new SortingAlgorithm();
    }

    /**
     * Sorts the data using the Quick Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithQuickSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] quickSortedData = sortingAlgorithm.quickSort(currentData.clone());
        System.out.println("Quick Sort Result:");
        sortingAlgorithm.displayArray(quickSortedData); // Correct usage of displayArray method
        System.out.println("Number of comparisons in Quick Sort: " + sortingAlgorithm.getComparisonCount());
    }

    /**
     * Sorts the data using the Merge Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithMergeSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] mergeSortedData = sortingAlgorithm.mergeSort(currentData.clone());
        System.out.println("Merge Sort Result:");
        sortingAlgorithm.displayArray(mergeSortedData);
        System.out.println("Number of comparisons in Merge Sort: " + sortingAlgorithm.getComparisonCount());
    }

    /**
     * Sorts the data using the Heap Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithHeapSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] heapSortedData = sortingAlgorithm.heapSort(currentData.clone());
        System.out.println("Heap Sort Result:");
        sortingAlgorithm.displayArray(heapSortedData);
        System.out.println("Number of comparisons in Heap Sort: " + sortingAlgorithm.getComparisonCount());
    }

    /**
     * Sorts the data using the Selection Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithSelectionSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] selectionSortedData = sortingAlgorithm.selectionSort(currentData.clone());
        System.out.println("Selection Sort Result:");
        sortingAlgorithm.displayArray(selectionSortedData);
        System.out.println("Number of comparisons in Selection Sort: " + sortingAlgorithm.getComparisonCount());
    }

    /**
     * Sorts the data using the Insertion Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithInsertionSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] insertionSortedData = sortingAlgorithm.insertionSort(currentData.clone());
        System.out.println("Insertion Sort Result:");
        sortingAlgorithm.displayArray(insertionSortedData);
        System.out.println("Number of comparisons in Insertion Sort: " + sortingAlgorithm.getComparisonCount());
    }

    /**
     * Sorts the data using the Bubble Sort algorithm.
     * Displays the sorted result and prints the number of comparisons made during sorting.
     */
    public void sortWithBubbleSort() {
        Integer[] currentData = dataManagement.getData(); // Retrieve data from DataManagement
        Integer[] bubbleSortedData = sortingAlgorithm.bubbleSort(currentData.clone());
        System.out.println("Bubble Sort Result:");
        sortingAlgorithm.displayArray(bubbleSortedData);
        System.out.println("Number of comparisons in Bubble Sort: " + sortingAlgorithm.getComparisonCount());
    }
}
