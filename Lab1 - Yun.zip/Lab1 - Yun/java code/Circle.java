

/* lab 1
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */


 package java3;


 class Circle {
     private double radius;
 
     // how to find the area of a circle 
     public double calculate() {
         return 3.14 * Math.pow(radius, 2);
     }
 
     // to display information about the the circle 
     @Override
     public String toString() {
         return "your input radius is " + radius + "";
     }
     
     // Getter
     public double getter() {
         return radius;
     }
     
     // Setter
     public void setter(double radius) {
         this.radius = radius;
     }
 }
 
 
 