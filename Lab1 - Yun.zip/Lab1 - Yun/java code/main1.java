
/* lab 1
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */

package java3;

import java.util.Scanner;

public class main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        // create a new instance of circle 
        Circle circle = new Circle();

        // ask the user to enter a radius
        System.out.print("Enter the radius of a circle:");
        double radius = scanner.nextDouble();

        // set radius using setter
        circle.setter(radius);

        // output radius information of the entered circle 
        System.out.println(circle);

        // Calculate the area of the circle under the given conditions
        double result = circle.calculate();
        System.out.println("calculated area of a circle is: " + result);

        scanner.close();
    }
}
	
