/* lab 2
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */

package lab2yun;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
    	
    	// introduction and instructions
    	System.out.println("I want to get your information to organize the list");
        System.out.println("I will ask your name and id");

        // arraylist to store student objects
        ArrayList<student> students = new ArrayList<>();

        // using scanner to get user input 
        Scanner scanner = new Scanner(System.in);

        // variables to check if the user want to input another student 
        String inputAnother;

        // input loop 
        do {
            try {

            	// input student id 
                System.out.print("\nWhat is your student ID?  ");
                int id = scanner.nextInt();

                // use new line 
                scanner.nextLine();

                // check the input values are correct or not
                String name;
                do {
                    System.out.print("\nWhat is your name?  ");
                    name = scanner.nextLine().trim();
                    if (!name.matches("[a-zA-Z]+")) {
                        System.err.println("you entered wrong value. input correct answer.");
                    }
                } while (!name.matches("[a-zA-Z]+"));


                // create another student object and add it to the arraylist
                student newStudent = new student(id, name);
                students.add(newStudent);


                // ask the user, if user wants to enter another student information
                String response;
                do {
                    System.out.print("\nDo you want to enter more student information? (answer: Y/N): ");
                    response = scanner.nextLine();
                    if (!response.equalsIgnoreCase("Y") && !response.equalsIgnoreCase("N")) {
                        System.err.println("you enter wrong answer. Enter 'Y' or 'N'.");
                    }
                } while (!response.equalsIgnoreCase("Y") && !response.equalsIgnoreCase("N"));

                inputAnother = response;

                // check the input values are correct or not. 
            } catch (InputMismatchException e) {
                System.err.println("you entered wrong value. input correct answer.");
                scanner.nextLine(); // consume the invalid input 
                inputAnother = "Y"; // continue the loop
            }

        } while (inputAnother.equalsIgnoreCase("Y"));

        // close the scanner
        scanner.close();

        Collections.sort(students, student.studentcomparator);

        // display the sorted result. 
        System.out.println("\nStudents List:");
        for (student s : students) {
            System.out.println(s);
        }

    }
}
