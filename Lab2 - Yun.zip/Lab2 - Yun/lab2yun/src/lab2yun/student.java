/* lab 2
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */

package lab2yun;
import java.util.Comparator;

public class student {

	// private fields to store personal information(ID, name)
    private int ID;
    private String NAME;

    // constructor to initiate student with id and name
    public student(int id, String name) {
        this.ID = id;
        this.NAME = name;
    }

    // setter for student id
    public void IDset(int ID) {
        if (ID > 0 && ID < 100000) {
            this.ID = ID;
        } 
        // if id is invalid value, then id=0
        else {
            this.ID = 0;
        }
    }

    // setter for student name 
    public void nameset(String name) {
        if (name == null) {
            this.NAME = "name";
        } 
        // if name is invalid value, then name = NA
        else {
            this.NAME = "NA";
        }
    }

    // getter for id 
    public int IDgetter() {
        return ID;
    }

    // getter for name 
    public String NAMEgetter() {
        return NAME;
    }

    // comparator for sorting students using their id and name
    public static Comparator<student> studentcomparator = new Comparator<student>() {
        public int compare(student s1, student s2) {
        	// get a lowercase version of the name for non-case comparison
            String sname1 = s1.NAMEgetter().toLowerCase();
            String sname2 = s2.NAMEgetter().toLowerCase();

            // compare names 
            if (sname1.equals(sname2)) {
                int sid1 = s1.IDgetter();
                int sid2 = s2.IDgetter();

                return sid1 - sid2;
                
            } else 
            	
            	// returns the result of name comparison if the name is different
                return sname1.compareTo(sname2);
            }
        };

        // override toString method for meaningful string representation
        @Override
        public String toString() {
            return "Student ID: " + ID + ", Name: " + NAME;
        }
       }


