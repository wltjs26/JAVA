/* lab 3
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */


// Main.java
package lab3yun;

import java.util.Arrays;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        // Enter the specified value - array size
        int arraySize = 10000;

        // Generate an array of 10,000+ random integers
        int[] arr = SelectionSort.randomArray(arraySize);


        // Perform Selection Sort
        long startTime = System.nanoTime();
        SelectionSort.selectionSort(arr);
        long endTime = System.nanoTime();


        
        // Calculate and print the execution time
        long runningTime = endTime - startTime;
        System.out.println("total time spent on the array");
        System.out.println("\nSorting Result - Selection Sort: " + runningTime + " ns");
    }
}
