/* lab 3
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */


// SelectionSort.java
package lab3yun;

import java.util.Random;
import java.util.Arrays;

public class SelectionSort {

    // Function to generate an array of random integers
    public static int[] randomArray(int size) {
        Random rand = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            // Generate random numbers between 0 and size-1
            arr[i] = rand.nextInt(size);
        }
        return arr;
    }

    // Modified selectionSort method
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            int j = i + 1;

            do {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
                j++;
            } while (j < n);

            int temp = 0;
            temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}
