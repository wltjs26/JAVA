ReadMe: Implementing Selective Alignment

This Java program shows the implementation of the Selection Sort algorithm. The program consists of two files:

Main.java: This file contains the main methods for creating a random integer array using the RandomArray method in the SelectionSort class. 
Print the unordered array and then apply the selectionSort method to sort the array. 
Print the last aligned array and run time.

SelectionSort.java: This file contains the RandomArray method to create a random integer array 
and the SelectionSort method that performs the SelectionSort algorithm for a given array.

How to use it:

Run the Main.java file.
The program creates a random integer array, prints the unaligned array, 
then sorts it using Selective Alignment, and then prints the aligned array in nanoseconds with run time.