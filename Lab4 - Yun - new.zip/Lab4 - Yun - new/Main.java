/* lab 4
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun
 */


package lab4yun;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    private static final int MAX_SIZE = 50; // Choose an appropriate maximum size

    private static Employee[] stack = new Employee[MAX_SIZE];
    private static int top = -1;

    public static void main(String[] args) {
        readfile("Emp.txt");

        // Top element output in the stack
        // Verify that the stack is empty.
        System.out.println(top != -1 ? "Top element from stack: ID:" + stack[top].id + ", Name:" + stack[top].name : "Stack is empty.");

        // Performs the function of removing two elements from the stack
        // only if the stack is not empty.
        if (top != -1) {
            Employee pop1 = pop();
            Employee pop2 = pop();
        }

        // Performs the function of checking and outputting
        // top-level elements only if the stack is not empty.
        if (top != -1) {
            System.out.println("Popping two elements from stack:");
            System.out.println("After popping, top element from stack: ID:" + stack[top].id + ", Name:" + stack[top].name);
        } else {
            System.out.println("Stack is empty.");
        }

        // Create new employee objects and add them to the stack.
        Employee newEmployee = new Employee(999, "Gabriel");
        push(newEmployee);

        // Only if the stack is not empty can you add new data
        // and then check and output the top element of the stack.
        if (top != -1) {
            System.out.println("After pushing new data, top element from stack: ID:" + stack[top].id + ", Name:" + stack[top].name);
        } else {
            System.out.println("Stack is empty.");
        }
    }

    // It reads data from a file, converts each line into an Employee object,
    // and adds it to the stack.
    public static void readfile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");

                if (parts.length >= 2) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    push(new Employee(id, name));
                } else {
                    System.out.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    // Manually implement push operation
    private static void push(Employee employee) {
        if (top < MAX_SIZE - 1) {
            stack[++top] = employee;
        }
    }

    private static Employee pop() {
        if (top != -1) {
            return stack[top--];
        }
        return null;
    }
}
