package lab5yun;

public class Jacob {

    public static void runRecursive(int n) {
        for (int i = 0; i <= n; i++) {
            System.out.print(calculateRecursive(i) + " ");
        }
    }

    public static int calculateRecursive(int n) {
        if (n <= 1) {
            return n;
        }
        return calculateRecursive(n - 1) + 2 * calculateRecursive(n - 2);
    }

    public static void runIterative(int n) {
        int prev1 = 0, prev2 = 1;
        System.out.print("0 1 ");
        for (int i = 2; i <= n; i++) {
            int current = prev2 + 2 * prev1;
            System.out.print(current + " ");
            prev1 = prev2;
            prev2 = current;
        }
    }
}
