
# Jacobstal number printer

## Introduction
This Java program calculates and outputs the Jacobstal sequence up to the specified value 'n'. Include both recursive and iterative versions for comparison.

## File Structure
- main.java: main java program with user interface and Jacobsthal sequence printer method.
- 'README.md ': File that provides an overview of the program.

## How to use it
1. Compile a Java program using a Java compiler 
2. Run compiled programs 
3. When prompted, enter a value of 'n'.
4. The program uses both a recursive and iterative approach to output Jacobstal sequences up to a specified value, along with the time required for each.

## Recursive Jacobstal Printer
- The print Jacobsthal R method outputs Jacobsthal sequences using a recursive approach.
- The recursive helper function, which computes the Jakobstal number, is 'Jakobstal R'.

## Repeated Jacobstal Printer
- The print Jacobsthal I method outputs Jacobsthal sequences using an iterative approach.

## Province
- The program measures and displays the time it takes for both the recursive and iterative versions.