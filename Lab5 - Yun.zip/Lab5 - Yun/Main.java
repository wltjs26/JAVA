package lab5yun;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

        // Recursive version
        long startTimeR = System.nanoTime();
        System.out.print("Recursive version: ");
        Jacob.runRecursive(n);
        System.out.println();

        long endTimeR = System.nanoTime();
        double timeTakenR = (endTimeR - startTimeR) / 1e6;
        System.out.printf("Time taken to execute Recursive version: %.2f ms%n", timeTakenR);

        // Iterative version
        long startTime1 = System.nanoTime();
        System.out.print("Iterative version: ");
        Jacob.runIterative(n);
        System.out.println();
        
        // Use System.nanoTime() to record the end time
        // Calculates the time required by subtracting the start time from the end time
        // Print using print to print the time (in milliseconds)
        long endTime1 = System.nanoTime();
        double timeTaken1 = (endTime1 - startTime1) / 1e6;
        System.out.printf("Time taken to execute Iterative version: %.2f ms%n", timeTaken1);

        scanner.close();
    }
}
