
# Maximum Finder

## Introduction
This Java program uses a recursive approach to calculate maximum values from the first size element of an integer array.

## Maximum Finder
The program defines 'maximum', a recursive method of finding maximum values in an array, which uses a switch case structure to compare the maximum values of the remaining elements with the current one.

## File Structure
- "Maximum.java": a major Java program that includes recursive methods.
- 'README.md ': File that provides an overview of the program.

## How to use it
1. Compile a Java program using a Java compiler (for example, 'javaacMaximum.java').
2. Run compiled programs (for example, 'java Maximum').
3. The program outputs the maximum value in a given array.

## Province
- The recursive method uses a switch case structure for simplicity.