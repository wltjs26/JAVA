/* lab 5
 * Course CS 401
 * Professor: Michael Choi
 * Students: Jisun Yun 
 */

package lab5yun;

public class Maximum {
	
	public static int maximum(int A[], int size) {
	    switch (size) {
	 // Base case: If the size is 1, the maximum is the only element in the array.
	        case 1:
	            return A[0];

	         // Recursive case: Finds the maximum value in the remaining elements of the array.
	        default:
	            int maxInRest = maximum(A, size - 1);

	         // Compare the maximum value of the remaining elements to the current element.
	            return Math.max(maxInRest, A[size - 1]);
	    }
	}

    public static void main(String args[]) {
        int A[] = {10, -20, 1, 2, 0, 5, 100};
        int result = maximum(A, A.length);

        System.out.println("The maximum value is: " + result);
    }
}
