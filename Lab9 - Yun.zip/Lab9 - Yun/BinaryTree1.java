package lab9yun;

public class BinaryTree1 {
    TreeNode root;

    public BinaryTree1() {
        root = null;
    }

    // Insertion method
    public void insert(int data) {
        root = insertRecursive(root, data);
    }

    private TreeNode insertRecursive(TreeNode root, int data) {
        if (root == null) {
            root = new TreeNode(data);
            return root;
        }

        if (data < root.data)
            root.left = insertRecursive(root.left, data);
        else if (data > root.data)
            root.right = insertRecursive(root.right, data);

        return root;
    }

    // Remaining methods as before...

    // Method to find the maximum depth of the tree
    public int maxDepth() {
        return maxDepth(root);
    }

    private int maxDepth(TreeNode node) {
        if (node == null)
            return 0;
        else {
            int leftDepth = maxDepth(node.left);
            int rightDepth = maxDepth(node.right);

            return Math.max(leftDepth, rightDepth) + 1;
        }
    }
}
