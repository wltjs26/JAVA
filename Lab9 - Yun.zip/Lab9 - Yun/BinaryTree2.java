package lab9yun;

import java.util.Stack;

public class BinaryTree2 {
    TreeNode root;

    public BinaryTree2() {
        root = null;
    }

    // Insertion method
    public void insert(int data) {
        root = insertRecursive(root, data);
    }

    private TreeNode insertRecursive(TreeNode root, int data) {
        if (root == null) {
            root = new TreeNode(data);
            return root;
        }

        if (data < root.data)
            root.left = insertRecursive(root.left, data);
        else if (data > root.data)
            root.right = insertRecursive(root.right, data);

        return root;
    }

    // Recursive method to calculate the size of the tree
    public int sizeRecursive() {
        return sizeRecursive(root);
    }

    private int sizeRecursive(TreeNode node) {
        if (node == null)
            return 0;
        else
            return sizeRecursive(node.left) + 1 + sizeRecursive(node.right);
    }

    // Iterative method to calculate the size of the tree
    public int sizeIterative() {
        if (root == null)
            return 0;

        int size = 0;
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);

        while (!stack.isEmpty()) {
            TreeNode currentNode = stack.pop();
            size++;

            if (currentNode.right != null)
                stack.push(currentNode.right);
            if (currentNode.left != null)
                stack.push(currentNode.left);
        }

        return size;
    }
}
