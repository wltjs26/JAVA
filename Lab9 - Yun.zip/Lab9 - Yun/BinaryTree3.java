package lab9yun;

public class BinaryTree3 {
    TreeNode root;

    public BinaryTree3() {
        root = null;
    }

 // Insertion
    public void insert(int data) {
        if (root == null) {
            root = new TreeNode(data);
            return;
        }

        TreeNode newNode = new TreeNode(data);
        TreeNode current = root;
        TreeNode parent = null;

        while (true) {
            parent = current;
            if (data < current.data) {
                current = current.left;
                if (current == null) {
                    parent.left = newNode;
                    return;
                }
            } else {
                current = current.right;
                if (current == null) {
                    parent.right = newNode;
                    return;
                }
            }
        }
    }


 // Recursive Size Calculation
    public int sizeRecursive(TreeNode node) {
        if (node == null)
            return 0;
        else {
            int leftSize = sizeRecursive(node.left); // Calculate size of left subtree
            int rightSize = sizeRecursive(node.right); // Calculate size of right subtree
            return leftSize + 1 + rightSize; // Return total size including current node
        }
    }

    // Iterative Size Calculation
    public int sizeIterative() {
        if (root == null)
            return 0;

        int size = 0;
        Stack stack = new Stack(100);
        stack.push(root);

        while (!stack.isEmpty()) {
            TreeNode currentNode = stack.pop();
            size++;

            if (currentNode.right != null)
                stack.push(currentNode.right);
            if (currentNode.left != null)
                stack.push(currentNode.left);
        }

        return size;
    }

    // Inorder Traversal
    public int[] inorderTraversal() {
        int[] result = new int[sizeIterative()];
        int index = 0;
        Stack stack = new Stack(100);
        TreeNode current = root;

        while (current != null || !stack.isEmpty()) {
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            current = stack.pop();
            result[index++] = current.data;
            current = current.right;
        }

        return result;
    }

 // Preorder Traversal
    public int[] preorderTraversal() {
        if (root == null)
            return new int[0]; // Return an empty array if the tree is empty
        int treeSize = sizeIterative();
        int[] result = new int[treeSize];
        int index = 0;

        // Stack for iterative traversal
        TreeNode[] stack = new TreeNode[treeSize]; // Max size for stack
        int top = -1; // Pointer to top of stack

        stack[++top] = root; // Push root to stack

        // Perform iterative preorder traversal
        while (top >= 0) {
            TreeNode currentNode = stack[top--]; // Pop node from stack
            result[index++] = currentNode.data;

            if (currentNode.right != null)
                stack[++top] = currentNode.right; // Push right child to stack
            if (currentNode.left != null)
                stack[++top] = currentNode.left; // Push left child to stack
        }

        return result; // Return the preorder traversal result
    }


    // Postorder Traversal
    public int[] postorderTraversal() {
        int[] result = new int[sizeIterative()];
        int index = 0;
        Stack stack1 = new Stack(100);
        Stack stack2 = new Stack(100);
        stack1.push(root);

        while (!stack1.isEmpty()) {
            TreeNode currentNode = stack1.pop();
            stack2.push(currentNode);

            if (currentNode.left != null)
                stack1.push(currentNode.left);
            if (currentNode.right != null)
                stack1.push(currentNode.right);
        }

        while (!stack2.isEmpty()) {
            result[index++] = stack2.pop().data;
        }

        return result;
    }
}
