package lab9yun;

public class Main1 {
    public static void main(String[] args) {
        BinaryTree1 tree = new BinaryTree1();
        int[] nodes = {25, 15, 50, 10, 22, 35, 70, 4, 12, 18, 24, 31, 44, 66, 90};
        for (int node : nodes) {
            tree.insert(node);
        }

        // Calculate maximum depth
        int maxDepth = tree.maxDepth();
        System.out.println("Maximum depth of the tree: " + maxDepth);
        
        
    }
}
