package lab9yun;

public class Main2 {
    public static void main(String[] args) {
        BinaryTree2 tree = new BinaryTree2();
        int[] nodes = {25, 15, 50, 10, 22, 35, 70, 4, 12, 18, 24, 31, 44, 66, 90};
        for (int node : nodes) {
            tree.insert(node);
        }

        // Calculate size recursively
        int recursiveSize = tree.sizeRecursive();
        System.out.println("Recursive Size: " + recursiveSize);

        // Calculate size iteratively
        int iterativeSize = tree.sizeIterative();
        System.out.println("Iterative Size: " + iterativeSize);
    }
}
