package lab9yun;

public class Main3 {
    public static void main(String[] args) {
        BinaryTree3 tree = new BinaryTree3();
        int[] nodes = {25, 15, 50, 10, 22, 35, 70, 4, 12, 18, 24, 31, 44, 66, 90};
        for (int node : nodes) {
            tree.insert(node);
        }

        // Calculate size
        int recursiveSize = tree.sizeRecursive(tree.root);
        int iterativeSize = tree.sizeIterative();
        System.out.println("Size of Recursive: " + recursiveSize);
        System.out.println("Size of Iterative: " + iterativeSize);

        // Inorder traversal
        int[] inorderTraversal = tree.inorderTraversal();
        System.out.print("Inorder Traversal: ");
        for (int node : inorderTraversal) {
            System.out.print(node + " ");
        }
        System.out.println();

        // Preorder traversal
        int[] preorderTraversal = tree.preorderTraversal();
        System.out.print("Preorder Traversal: ");
        for (int node : preorderTraversal) {
            System.out.print(node + " ");
        }
        System.out.println();

        // Postorder traversal
        int[] postorderTraversal = tree.postorderTraversal();
        System.out.print("Postorder Traversal: ");
        for (int node : postorderTraversal) {
            System.out.print(node + " ");
        }
        System.out.println();
    }
}
