package lab9yun;

public class Stack {
    private int top;
    private TreeNode[] array;

    public Stack(int capacity) {
        array = new TreeNode[capacity];
        top = -1;
    }

    public void push(TreeNode node) {
        if (top == array.length - 1) {
            System.out.println("Stack overflow");
            return;
        }
        array[++top] = node;
    }

    public TreeNode pop() {
        if (top == -1) {
            System.out.println("Stack underflow");
            return null;
        }
        return array[top--];
    }


    public boolean isEmpty() {
        return top == -1;
    }
}
