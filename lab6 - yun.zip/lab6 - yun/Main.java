package lab6yun;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Queue fixedFrontQueue = new Queue();
        Queue floatingFrontQueue = new Queue();

        readfile("emp.txt", fixedFrontQueue, 10);
        readfile("emp.txt", floatingFrontQueue, 10);

        // Enqueue and print elements for Fixed Front Design
        System.out.println("Elements stored in Fixed Front Queue:");
        fixedFrontQueue.printq();

        // Dequeue thrice for Fixed Front Design
        fixedFrontQueue.dequeue();
        fixedFrontQueue.dequeue();
        fixedFrontQueue.dequeue();

        // Print elements after dequeuing for Fixed Front Design
        System.out.println("\nElements stored in Fixted Front Queue After Dequeueing thrice:");
        fixedFrontQueue.printq();

        // Enqueue and print elements for Floating Front Design
        System.out.println("\nElements stored in Floating Front Queue:");
        floatingFrontQueue.printq();

        // Dequeue thrice for Floating Front Design
        floatingFrontQueue.dequeue();
        floatingFrontQueue.dequeue();
        floatingFrontQueue.dequeue();

        // Print elements after dequeuing for Floating Front Design
        System.out.println("\nElements stored in Floating Front Queue After Dequeueing thrice:");
        floatingFrontQueue.printq();
    }

    public static void readfile(String filename, Queue queue, int numberOfElements) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int count = 0;

            while ((line = br.readLine()) != null && count < numberOfElements) {
                Employee employee = pEmployee(line);

                if (employee != null) {
                    queue.enqueue(employee);
                    count++;
                } else {
                    System.out.println("Error file: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error file: " + e.getMessage());
        }
    }

    private static Employee pEmployee(String line) {
        String[] parts = line.split(" ");

        if (parts.length >= 2) {
            try {
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                return new Employee(id, name);
            } catch (NumberFormatException e) {
                System.out.println("Wrong ID: " + parts[0]);
            }
        } else {
            System.out.println("Wrong data: " + line);
        }

        return null;
    }

}