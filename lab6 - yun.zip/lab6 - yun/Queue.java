package lab6yun;

public class Queue {
    private static final int MAX_SIZE = 30;
    private Employee[] array = new Employee[MAX_SIZE];
    private int front = 0;
    private int rear = -1;

    public boolean enqueue(Employee employee) {
        if (rear < MAX_SIZE - 1) {
            array[++rear] = employee;
            return true;
        }
        return false;
    }

    public Employee dequeue() {
        if (front <= rear) {
            Employee dequeued = array[front++];
            return dequeued;
        }
        return null;
    }

    public void printq() {
        for (int i = front; i <= rear; i++) {
            System.out.println("Employee{name='" + array[i].name + "', id=" + array[i].id + "}");
        }
    }
}
