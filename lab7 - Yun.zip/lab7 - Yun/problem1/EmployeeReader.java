// EmployeeReader.java
package lab7yun;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EmployeeReader {
    public static Employee[] readFromFile(String fileName) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        int count = 0;
        while ((line = br.readLine()) != null) {
            count++;
        }
        br.close();
        BufferedReader br2 = new BufferedReader(new FileReader(fileName));
        Employee[] employees = new Employee[count];
        int index = 0;
        while ((line = br2.readLine()) != null) {
            String[] parts = line.split(" ");
            int id = Integer.parseInt(parts[0]);
            String name = parts[1];
            employees[index++] = new Employee(id, name);
        }
        return employees;
    }
}
