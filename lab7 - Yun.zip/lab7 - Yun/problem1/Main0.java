// Main.java
package lab7yun;

import java.io.IOException;

public class Main0 {
    public static void main(String[] args) {
        String fileName = "Emp.txt";
        try {
            Employee[] employees = EmployeeReader.readFromFile(fileName);

            // Sort employee items by ID using Selection Sort method
            Sorting.SelectionSort(employees, 0, employees.length);

            // Print sorted employee IDs and names for the first 10 employees
            System.out.println("Sorted Employee IDs and Names:");
            for (int i = 0; i < Math.min(10, employees.length); i++) {
                Employee employee = employees[i];
                System.out.println("ID: " + employee.getId() + ", Name: " + employee.getName());
            }

            // Test binary search
            Employee searchEmployee = new Employee(9, ""); // Example search for ID 9
            int index = Sorting.binarySearch(employees, 0, employees.length - 1, searchEmployee);
            if (index != -1) {
                System.out.println("Employee found at index " + index + ": " + employees[index].getId() + " " + employees[index].getName());
            } else {
                System.out.println("Employee not found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
