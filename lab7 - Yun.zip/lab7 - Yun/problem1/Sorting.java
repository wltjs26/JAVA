// Sorting.java
package lab7yun;

public class Sorting {
	// The selection alignment algorithm works by comparing the elements in the current location 
	// with the rest of the elements while traversing the array to find a minimum, and exchanging that minimum with the current location.
    public static void SelectionSort(Employee array[], int low, int high) {
        for (int i = low; i < high - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < high; j++) {
                if (array[j].getId() < array[minIndex].getId()) {
                    minIndex = j;
                }
            }
            Employee temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }

    // A binary search algorithm is an algorithm that efficiently finds a particular key in an array that has already been sorted. 
    // It divides the array in half to narrow the search range and find the key.
    public static int binarySearch(Employee array[], int low, int high, Employee key) {
        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = array[mid].getId() - key.getId();
            if (cmp == 0) {
                return mid;
            } else if (cmp < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }
}
