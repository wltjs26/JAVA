package lab7yun1;

public class Calculator {
	// Method to return results by performing appropriate operations in the order of operands
    public static int evaluate(int operand1, int operand2, char operator) {
        int result;
        if (operator == '-') {
            result = operand1 - operand2;
        } else if (operator == '/') {
            if (operand2 != 0) {
                result = operand1 / operand2;
            } else {
                throw new ArithmeticException("Division by zero");
            }
        } else {
        	// The remaining operators perform the same operations in any order.
            switch (operator) {
                case '+':
                    result = operand1 + operand2;
                    break;
                case '*':
                    result = operand1 * operand2;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid operator");
            }
        }
        return result;
    }
}
