package lab7yun1;

public class Main1 {
    
    // main method: entry point of the program
    public static void main(String[] args) {
        // Array of infix expressions
        String[] infixExpressions = {"1+9*3", "9+6-3*2+5", "5+2-8/2+6-7+6*3"};

        // Iterate through the array of infix expressions
        for (String infix : infixExpressions) {
            // Print the infix expression
            System.out.println("Infix: " + infix);
            System.out.println("Outputs");
            // Convert the infix expression to postfix
            String postfix = Itofconverter.infixToPostfix(infix);
            // Print the postfix expression
            System.out.println(" 1. Postfix: " + postfix);
            // Evaluate the postfix expression and print the result
            int evaluation = Postconverter.evaluatePostfix(postfix);
            // Print the evaluation result
            System.out.println(" 2. Evaluation: " + evaluation);
            // Print a new line
            System.out.println();
        }
    }
}
