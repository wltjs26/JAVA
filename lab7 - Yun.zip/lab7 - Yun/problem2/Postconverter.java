package lab7yun1;

// Classes that implement the evaluatePostfix method, which evaluates a given posterior expression and returns a result. 
// The posterior expression is an expression in which the operator is placed after the operand, making it easy to calculate.
public class Postconverter {
    public static int evaluatePostfix(String postfix) {
        Stack<Integer> stack = new Stack<>(postfix.length());

        for (int i = 0; i < postfix.length(); i++) {
            char c = postfix.charAt(i);
            if (Character.isDigit(c)) {
                int digit = Character.getNumericValue(c);
                stack.push(digit);
            } else {
                int operand2 = stack.pop();
                int operand1 = stack.pop();
                int result = Calculator.evaluate(operand1, operand2, c);
                stack.push(result);
            }
        }

        return stack.pop();
    }
}
