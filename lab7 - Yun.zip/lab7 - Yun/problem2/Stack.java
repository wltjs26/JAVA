package lab7yun1;

public class Stack<T> {
    private int maxSize;
    private T[] stackArray;
    private int top;

    //The warning was suppressed because the generic arrangement will be used safely.
    @SuppressWarnings("something wrong")
    public Stack(int maxSize) {
        this.maxSize = maxSize;
        this.stackArray = (T[]) new Object[maxSize];
        this.top = -1;
    }

    // Add an element to the stack. 
    // If the stack is full, it will generate IllegalStateException.
    public void push(T element) {
        if (isFull()) {
            throw new IllegalStateException("Stack is full");
        }
        top++;
        stackArray[top] = element;
    }

    // Remove and return the element at the top of the stack. 
    // If the stack is empty, it will cause IllegalStateException.
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        T element = stackArray[top];
        top--;
        return element;
    }

    // Returns the element at the top of the stack, just checking without removing it. 
    // If the stack is empty, it will cause IllegalStateException.
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stackArray[top];
    }

    // Check stack status
    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == maxSize - 1;
    }
}
