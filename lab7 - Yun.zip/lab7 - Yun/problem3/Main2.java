package lab7yun2;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PalindromeChecker checker = new PalindromeChecker();

        // This code is a loop that receives a sentence from the user and determines whether the entered sentence is palindrome.
        while (true) {
            System.out.print("Enter a sentence (or 'end' to quit): ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("end")) {
                break; // Exit the loop if user enters 'end'
            }

            if (checker.isPalindromeWithConditions(input)) {
                System.out.println("This is a palindrome.");
            } else {
                System.out.println("This is not a palindrome.");
            }
        }

        scanner.close();
    }
}
