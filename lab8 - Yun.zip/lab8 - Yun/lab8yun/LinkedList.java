package lab8yun;

public class LinkedList {

    protected Node head;

    protected class Node {
        int emp_id;
        String name;
        Node next;

        Node(int emp_id, String name) {
            this.emp_id = emp_id;
            this.name = name;
            this.next = null;
        }
    }

    public void add(int emp_id, String name) {
        Node newNode = new Node(emp_id, name);
        if (head == null) {
            // If the list is empty, set the new node as the head
            head = newNode;
        } else {
            // If the list is not empty, find the last node and add the new node after it
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }


    public void remove(int emp_id) {
        Node current = head;
        Node previous = null;

        // Traverse the list to find the node with the specified employee ID
        while (current != null && current.emp_id != emp_id) {
            previous = current;
            current = current.next;
        }

        // If the node with the specified employee ID is not found
        if (current == null) {
            System.out.println("Employee with ID " + emp_id + " not found.");
            return;
        }

        // If the node to be deleted is the head node
        if (previous == null) {
            head = current.next;
        } else {
            // If the node to be deleted is not the head node
            previous.next = current.next;
        }
    }

    public void printList() {
        Node current = head;
        if (current == null) {
            System.out.println("The list is empty.");
            return;
        }

        while (current != null) {
            System.out.println("ID: " + current.emp_id + ", Name: " + current.name);
            current = current.next;
        }
    }


}
