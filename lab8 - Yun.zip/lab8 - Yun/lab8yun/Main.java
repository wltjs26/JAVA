package lab8yun;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        SortedLinkedList sortedList = new SortedLinkedList();
        readAndPrintEmployeeFile("Emp.txt", list, sortedList);
        System.out.println("\nUnsorted List:");
        list.printList();
        System.out.println("\nSorted List:");
        sortedList.printList();
        System.out.println("");

        // Remove employee with ID 18
        list.remove(18);
        sortedList.remove(18);
        System.out.println("\nList after removing employee with ID 18:");
        sortedList.printList();

        // Add employee with ID 31 and name "Eunwoo Cha"
        sortedList.add(31, "Eunwoo Cha");
        System.out.println("\nList after adding employee with ID 31 (Eunwoo Cha):");
        sortedList.printList();

        // Check if employee with ID 31 exists
        int empIdToCheck = 31;
        System.out.println("\nDoes the sorted list contain employee with ID " + empIdToCheck + "? " + sortedList.contains(empIdToCheck));
    }

    public static void readAndPrintEmployeeFile(String fileName, LinkedList list, SortedLinkedList sortedList) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            System.out.println("Emp.txt File Contents:");
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
                String[] parts = line.split(" ", 2); // Split by space into ID and name
                int emp_id = Integer.parseInt(parts[0]);
                String name = parts.length > 1 ? parts[1] : ""; // If name exists, assign it, otherwise empty string
                list.add(emp_id, name);
                sortedList.add(emp_id, name);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + fileName);
            e.printStackTrace();
        }
    }
}
