package lab8yun;

public class SortedLinkedList extends LinkedList {

    @Override
    public void add(int emp_id, String name) {
        Node newNode = new Node(emp_id, name);

        // If the list is empty or the new node should be inserted at the beginning
        if (head == null || head.emp_id >= emp_id) {
            newNode.next = head;
            head = newNode;
        } else {
            // Traverse the list to find the correct position for insertion
            Node current = head;
            while (current.next != null && current.next.emp_id < emp_id) {
                current = current.next;
            }
            // Insert the new node after the current node
            newNode.next = current.next;
            current.next = newNode;
        }
    }


    public boolean contains(int emp_id) {
        Node current = head;
        while (current != null) {
            if (current.emp_id == emp_id) {
                return true;
            }
            current = current.next;
        }
        return false;
    }


}
