package lab8yun1;

public class CircularLinkedList extends LinkedList {

    // Constructor
    public CircularLinkedList() {
        super();
    }

    // Method to insert a node at the end of the circular linked list
    public void insertLast(int emp_id, String name) {
        Node newNode = new Node(emp_id, name);
        if (head == null) {
            head = newNode;
            head.next = head; // 자기 자신을 가리키도록 설정하여 원형으로 만듦
        } else {
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head; // 마지막 노드의 다음 노드를 head로 설정하여 원형으로 만듦
        }
    }

    // Method to delete a node by employee ID
    public void deleteById(int emp_id) {
        if (head == null) {
            return;
        }
        if (head.emp_id == emp_id) {
            if (head.next == head) {
                head = null;
            } else {
                Node current = head;
                while (current.next != head) {
                    current = current.next;
                }
                current.next = head.next;
                head = head.next;
            }
            return;
        }
        Node prev = head;
        Node current = head.next;
        while (current != head) {
            if (current.emp_id == emp_id) {
                prev.next = current.next;
                return;
            }
            prev = current;
            current = current.next;
        }
    }

    // Method to display the circular linked list
    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        Node current = head;
        do {
            System.out.println("ID: " + current.emp_id + ", Name: " + current.name);
            current = current.next;
        } while (current != head);
    }

    // Method to check if the circular linked list contains a node with a given employee ID
    public boolean contains(int emp_id) {
        if (head == null) {
            return false;
        }
        Node current = head;
        do {
            if (current.emp_id == emp_id) {
                return true;
            }
            current = current.next;
        } while (current != head);
        return false;
    }

    // Method to get the head node
    public Node getHead() {
        return head;
    }
}
