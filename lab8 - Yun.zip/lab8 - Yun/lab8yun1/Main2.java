package lab8yun1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList(); // Create an instance of CircularLinkedList
        // Now we can use circularList
        readEmployeeFile("Emp.txt", circularList); // Example usage
        System.out.println("List after inserting:");
        circularList.display();

        int empIdToDelete = 11; // Example employee ID to delete
        System.out.println("\nDeleting employee with ID: " + empIdToDelete);
        circularList.deleteById(empIdToDelete);
        System.out.println("\nList after deletion:");
        circularList.display();

        // Check if there is an employee with ID 11 in the list
        int empIdToCheck = 11; // Example employee ID to check
        System.out.println("\nIs there an employee with an ID included in the list? ID is " + empIdToCheck + ". " + containsEmployee(circularList, empIdToCheck));
        
        // Print the contents of "Emp.txt" file
        System.out.println("\nContents of Emp.txt:");
        printFileContents("Emp.txt");

    }

    // Method to check if the circular list contains an employee with the given ID
    public static boolean containsEmployee(CircularLinkedList circularList, int emp_id) {
        if (circularList == null || circularList.getHead() == null) {
            return false;
        }
        CircularLinkedList.Node current = circularList.getHead();
        do {
            if (current.emp_id == emp_id) {
                return true;
            }
            current = current.next;
        } while (current != circularList.getHead());
        return false;
    }

    // Method to read employee data from a file and add them to the circular list
    public static void readEmployeeFile(String fileName, CircularLinkedList circularList) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            int count = 0;
            while (scanner.hasNextLine() && count < 8) { // Read only 8 employees
                String line = scanner.nextLine();
                String[] parts = line.split(" ", 2);
                int emp_id = Integer.parseInt(parts[0]);
                String name = parts.length > 1 ? parts[1] : ""; // Consider cases where name is missing
                circularList.insertLast(emp_id, name); // Add to the end using insertLast() method
                count++;
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error, no files");
            e.printStackTrace();
        }
    }

    // Method to print the contents of a file
    public static void printFileContents(String fileName) {
        File file = new File(fileName);
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error, no files");
            e.printStackTrace();
        }
    }

}
