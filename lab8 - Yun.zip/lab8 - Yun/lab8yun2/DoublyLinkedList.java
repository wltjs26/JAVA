package lab8yun2;

public class DoublyLinkedList extends LinkedList {

    protected static class Node extends LinkedList.Node {
        Node prev; // Reference to the previous node

        Node(int emp_id, String name) {
            super(emp_id, name);
            this.prev = null;
        }
    }

    @Override
    public void add(int emp_id, String name) {
        Node newNode = new Node(emp_id, name);
        if (head == null) {
            head = newNode;
        } else {
            Node current = (Node) head;
            while (current.next != null) {
                current = (Node) current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    @Override
    public void remove(int emp_id) {
        if (head == null) {
            return;
        }
        if (head.emp_id == emp_id) {
            head = head.next;
            if (head != null) {
                ((Node) head).prev = null;
            }
            return;
        }
        Node current = (Node) head;
        while (current != null && current.emp_id != emp_id) {
            current = (Node) current.next;
        }
        if (current != null) {
            if (current.next != null) {
                ((Node) current.next).prev = current.prev;
            }
            if (current.prev != null) {
                ((Node) current.prev).next = current.next;
            }
        }
    }


    @Override
    public boolean contains(int emp_id) {
        Node current = (Node) head;
        while (current != null) {
            if (current.emp_id == emp_id) {
                return true;
            }
            current = (Node) current.next;
        }
        return false;
    }

}
