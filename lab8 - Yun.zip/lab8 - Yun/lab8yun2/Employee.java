package lab8yun2;

class Employee {
	// id—The member variable that stores the identifier (ID) of the employee.
    int id;
    // name—The member variable that stores the employee's name.
    String name;
    
    //Employee(intid, string name)—The constructor method receives 
    // the employee's ID and name and initializes the Employee object.
    Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }
}