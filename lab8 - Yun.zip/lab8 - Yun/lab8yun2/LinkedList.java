package lab8yun2;

public class LinkedList {

    protected Node head;

    protected static class Node {
        int emp_id;
        String name;
        Node next;

        Node(int emp_id, String name) {
            this.emp_id = emp_id;
            this.name = name;
            this.next = null;
        }
    }

    public void add(int emp_id, String name) {
        Node newNode = new Node(emp_id, name);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public boolean contains(int emp_id) {
        Node current = head;
        while (current != null) {
            if (current.emp_id == emp_id) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public void remove(int emp_id) {
        Node current = head;
        Node previous = null;

        while (current != null && current.emp_id != emp_id) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Employee with ID " + emp_id + " not found.");
            return;
        }

        if (previous == null) {
            head = current.next;
        } else {
            previous.next = current.next;
        }
    }

    public void printList() {
        Node current = head;
        if (current == null) {
            System.out.println("The list is empty.");
            return;
        }

        while (current != null) {
            System.out.println("ID: " + current.emp_id + ", Name: " + current.name);
            current = current.next;
        }
    }
}
