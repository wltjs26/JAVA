package lab8yun2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        // Read employee information from file
        readEmployeeFile("Emp.txt", doublyList);

        // Display the contents of the employee file
        System.out.println("Contents of Emp.txt:");
        printFileContents("Emp.txt");

        // Remove an employee with ID 13
        int empIdToDelete = 13;
        doublyList.remove(empIdToDelete);
        System.out.println("\nList after removing an employee with ID " + empIdToDelete + ":");
        doublyList.printList();

        // Check if an employee with ID 13 exists in the list
        int empIdToCheck = 13;
        boolean containsEmployee = doublyList.contains(empIdToCheck);
        System.out.println("\nIs ID " + empIdToCheck + " present in the list? " + containsEmployee);

        // Add a new employee
        int newEmpId = 31;
        String newName = "Eunwoo Cha";
        doublyList.add(newEmpId, newName);
        System.out.println("\nAdding new employee: ID - " + newEmpId + ", Name - " + newName);
        System.out.println("List after adding new employee:");
        doublyList.printList();
    }

    // Method to read employee information from file and add it to the list
    public static void readEmployeeFile(String fileName, DoublyLinkedList doublyList) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" ", 2);
                int empId = Integer.parseInt(parts[0]);
                String name = parts.length > 1 ? parts[1] : "";
                doublyList.add(empId, name);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            e.printStackTrace();
        }
    }

    // Method to print the contents of a file
    public static void printFileContents(String fileName) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            e.printStackTrace();
        }
    }
}
